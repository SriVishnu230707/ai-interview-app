import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import MockInterview from "./pages/MockInterview";

function App() {
  return (
    <div>
      <Navbar />
      <Home />
      <MockInterview />
    </div>
  );
}

export default App;
