import { useState } from "react";
import API from "../api";

export default function MockInterview() {
  const [answer, setAnswer] = useState("");
  const [feedback, setFeedback] = useState("");

  const submitAnswer = async () => {
    const res = await API.post("/feedback", { answer });
    setFeedback(res.data.feedback);
  };

  return (
    <div className="p-10">
      <h1 className="text-2xl font-bold mb-4">
        Answer & Get Feedback ⭐
      </h1>

      <textarea
        className="border w-full p-4 rounded mb-4"
        rows="5"
        placeholder="Type your answer..."
        value={answer}
        onChange={(e) => setAnswer(e.target.value)}
      />

      <button
        onClick={submitAnswer}
        className="bg-green-600 text-white px-6 py-3 rounded-xl"
      >
        Get Feedback
      </button>

      {feedback && (
        <div className="mt-6 bg-gray-100 p-5 rounded-xl">
          <h2 className="font-bold text-xl">AI Feedback:</h2>
          <p>{feedback}</p>
        </div>
      )}
    </div>
  );
}
