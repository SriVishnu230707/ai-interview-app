import { useState } from "react";
import API from "../api";

export default function Home() {
  const [role, setRole] = useState("");
  const [question, setQuestion] = useState("");

  const startInterview = async () => {
    const res = await API.post("/question", { role });
    setQuestion(res.data.question);
  };

  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold mb-6">
        Start Your Mock Interview 🎤
      </h1>

      <input
        className="border p-3 w-full rounded mb-4"
        placeholder="Enter Role (Software Engineer, Data Scientist...)"
        value={role}
        onChange={(e) => setRole(e.target.value)}
      />

      <button
        onClick={startInterview}
        className="bg-blue-600 text-white px-6 py-3 rounded-xl"
      >
        Generate Question
      </button>

      {question && (
        <div className="mt-6 p-5 bg-gray-100 rounded-xl">
          <h2 className="font-bold text-xl">Question:</h2>
          <p>{question}</p>
        </div>
      )}
    </div>
  );
}
