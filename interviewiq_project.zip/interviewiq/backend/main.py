from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from ai_engine import generate_question, evaluate_answer

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class InterviewRequest(BaseModel):
    role: str

class AnswerRequest(BaseModel):
    answer: str

@app.post("/question")
def get_question(req: InterviewRequest):
    question = generate_question(req.role)
    return {"question": question}

@app.post("/feedback")
def get_feedback(req: AnswerRequest):
    feedback = evaluate_answer(req.answer)
    return {"feedback": feedback}
